import json
import csv

def run_quiz():
    # Get the file path and type from the user
    file_path = input("Enter the file path: ")
    file_type = input("Enter the file type (text, json, or csv): ")

    # Load the questions and answers from the file
    questions_and_answers = load_questions_and_answers(file_path, file_type)

    # Get the user's name
    user_name = input("Welcome to the quiz! Please enter your name: ")

    # Ask the questions and keep track of the score
    score = 0
    for i, (question, answer) in enumerate(questions_and_answers):
        user_answer = input(f"Question {i+1}: {question}\nYour answer: ")
        if user_answer.lower() == answer.lower():
            print("Correct!")
            score += 1
        else:
            print("Incorrect.")

    # Print the user's score
    print(f"You scored {score} out of {len(questions_and_answers)}.")

    # Save the user's name and result
    save_result(user_name, score, len(questions_and_answers))

def load_questions_and_answers(file_path, file_type):
    if file_type == "text":
        with open(file_path, "r") as file:
            lines = file.readlines()
            questions_and_answers = [(lines[i], lines[i+1].strip()) for i in range(0, len(lines), 2)]
    elif file_type == "json":
        with open(file_path, "r") as file:
            data = json.load(file)
            questions_and_answers = list(data.items())
    elif file_type == "csv":
        with open(file_path, "r") as file:
            reader = csv.reader(file)
            questions_and_answers = list(reader)
    else:
        raise ValueError("Invalid file type. Please enter 'text', 'json', or 'csv'.")
    return questions_and_answers

def save_result(user_name, score, total_questions):
    output_file_path = input(f"Enter the output file path (CSV or JSON): ")
    output_file_type = output_file_path.split(".")[-1]

    result = {
        "name": user_name,
        "score": score,
        "total_questions": total_questions
    }

    if output_file_type == "csv":
        with open(output_file_path, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([user_name, score, total_questions])
    elif output_file_type == "json":
        with open(output_file_path, "a") as file:
            json.dump(result, file)
            file.write("\n")
    else:
        raise ValueError("Invalid output file type. Please enter a CSV or JSON file.")

if __name__ == "__main__":
    run_quiz()