L1 = ['HTTP', 'HTTPS', 'FTP', 'DNS']
L2 = [80, 443, 21, 53]

d = dict(zip(L1, L2))

print(d)




#-----------------------------------------------------------------------------
# Define the factorial function
def factorial(n):
    # Base case: if n is 0 or 1, return 1
    if n == 0 or n == 1:
        return 1
    # Recursive case: return n multiplied by the factorial of n-1
    else:
        return n * factorial(n-1)

# Prompt the user to enter a number
num = int(input("Enter a number: "))

# Call the factorial function with the user's input and store the result
result = factorial(num)

# Print the factorial of the user's input
print(f"The factorial of {num} is {result}")


#-------------------------------------------------------------------------------
L = ['Network', 'Bio', 'Programming', 'Physics', 'Music']

for item in L:
    if item.startswith('B'):
        print(item)
# Output:
# Bio


#-------------------------------------------------------------------------------
d = {i: i+1 for i in range(11)}
print(d)
# Output: {0: 1, 1: 2, 2: 3, 3: 4, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9, 9: 10, 10: 11}