def binary_to_decimal(binary_num):


    decimal_num = 0
    for i, digit in enumerate(reversed(binary_num)):
        decimal_num += int(digit) * 2 ** i
    
    return decimal_num

# Prompt the user to enter a binary number
binary_number = input("Enter a binary number: ")

# Convert the binary number to decimal
decimal_result = binary_to_decimal(binary_number)

# Display the result
if isinstance(decimal_result, int):
    print("The  decimal number is: ",decimal_result)
else:
    print(decimal_result)