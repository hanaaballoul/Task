# Define a BankAccount class
class BankAccount:
    # Initialize the BankAccount object with an account number, account holder name, and initial balance of 0.0
    def __init__(self, string_account_number, string_account_holder):
        self.string_account_number = string_account_number
        self.string_account_holder = string_account_holder
        self.float_balance = 0.0
    
    # Deposit funds to the account
    def deposit(self, float_amount):
        self.float_balance += float_amount
        print(f"Deposited ${float_amount}.  current balance: ${self.float_balance:.2f}")
    
    # Withdraw funds from the account, if the balance is sufficient
    def withdraw(self, float_amount):
        if self.float_balance >= float_amount:
            self.float_balance -= float_amount
            print(f"Withdrew ${float_amount}.  current balance: ${self.float_balance:.2f}")
        else:
            print("Insufficient funds.")
    
    # Get the current balance of the account
    def get_balance(self):
        return self.float_balance

# Create an instance of BankAccount
bank_account = BankAccount("32165", "Hanaa balloul")

# Perform a deposit of $1000
bank_account.deposit(1000)

# Perform a withdrawal of $500
bank_account.withdraw(500)

# Define a SavingsAccount class that inherits from BankAccount
class SavingsAccount(BankAccount):
    # Initialize the SavingsAccount object with an account number, account holder name, and interest rate
    def __init__(self, string_account_number, string_account_holder, float_interest_rate):
        super().__init__(string_account_number, string_account_holder)
        self.float_interest_rate = float_interest_rate
    
    # Apply interest to the account balance
    def apply_interest(self):
        float_interest = self.float_balance * self.float_interest_rate
        self.float_balance += float_interest
        print(f"Applied {self.float_interest_rate*100:.2f}% interest.  current balance: ${self.float_balance:.2f}")
    
    # Override the __str__ method to print account details
    def __str__(self):
        return f"Account number: {self.string_account_number}\nAccount holder: {self.string_account_holder}\nBalance: ${self.float_balance:.2f}\nInterest rate: {self.float_interest_rate*100:.2f}%"

# Create an instance of SavingsAccount
savings_account = SavingsAccount("32165", "Hanaa balloul", 0.05)

# Apply interest and print the current balance and rate
savings_account.apply_interest()
print(savings_account)